/*
 * ARM pipeline timing simulator
 *
 * CMSC 22200, Fall 2016
 */

#ifndef _BP_H_
#define _BP_H_

typedef struct
{
    /* gshare */
    /* BTB */
} bp_t;



void bp_predict(/*......*/);
void bp_update(/*......*/);

#endif
