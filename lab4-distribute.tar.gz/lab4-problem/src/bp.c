/*
 * ARM pipeline timing simulator
 *
 * CMSC 22200, Fall 2016
 * Gushu Li and Reza Jokar
 */

#include "bp.h"
#include <stdlib.h>
#include <stdio.h>


void bp_predict(/*......*/)
{
    /* Predict next PC */
}

void bp_update(/*......*/)
{
    /* Update BTB */


    /* Update gshare directional predictor */


    /* Update global history register */

}
