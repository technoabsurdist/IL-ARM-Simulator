/*
 * CMSC 22200, Fall 2016
 *
 * ARM pipeline timing simulator
 *
 */

#include "cache.h"
#include <stdlib.h>
#include <stdio.h>


cache_t *cache_new(int sets, int ways, int block)
{

}

void cache_destroy(cache_t *c)
{

}


int cache_update(cache_t *c, uint64_t addr)
{

}

